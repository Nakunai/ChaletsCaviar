<?php

phpinfo(); // Pour connaitre l'ensemble des informations relatives au PHP utilisé par le serveur web, il existe une fonction PHP  phpinfo() //