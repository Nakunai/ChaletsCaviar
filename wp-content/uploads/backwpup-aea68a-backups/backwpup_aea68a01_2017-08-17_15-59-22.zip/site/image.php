<?php

header("Content-type: image/png"); /*Grâce à la bibliothèque GD(qu'il faut penser a activer dans l'onglet wamp/php/extension php/php_gd2) on peut générer des images grace a php.Il y a deux façon de faire, ici on utilise la fonction header
									qui permet de renvoyer une image au lieu d'une page web(Ne pas oublier les formats d'image les plus courant sont le JPEG(qu'on utilise pour les photos) et le PNG pour (tout le reste)).La fonction header est particulière,comme setcookie, elle doit etre utiliser avant tout le code html*/



$image = imagecreate(200, 50); /*Il y a deux façon pour créer une image,soit on créer une nouvelle image vide(comme ici) soit on charge une image qui existe deja et qui servira de fond a la nouvelle image.Pour créer une image vide, on utilise 
								la fonction imagecreate il faut lui indiquer 2 paramètres : la largeur et la hauteur(en px) et on stocke tout ça dans une ressource $image(une ressource est une variable un peu spécial qui contient toute les information sur un objet, ici il s'agit d'une image mais ca aurait pu etre un PDF ou meme un fichier)*/
 


header("Content-type: image/jpeg"); //La 2 eme facon est donc de créer une image a partir d'une image existante grâce a la fonction imagecreatefromjpeg(pour le format jpeg) et imagecreatefrompng(pour le png)//
$image = imagecreatefromjpeg("couchersoleil.jpg");
imagejpeg($image); // Ici on affiche notre image grace a la fonction imagejpeg(ou imagepng selon le format) //
<img src="image.php" />/* On peut ensuite afficher notre image de cette facon en htlm pour l'integrer dans le contenu car on a changer le header de notre page php qui la donc changer en image.Le gros avantage de cette technique, c'est que 
						l'image affichée pourras changer a chaque fois */


$image = imacreate(200,50);
imagepng($image, "images/monimage.png"); /*Ici au lieu d'afficher l'image,on l'enregistre sur le disque.Pour cela, on rajoute un parametre a la fonction imagepng le nom de l'image et son dossier.Plus besoin de header comme on n'affiche plu 
											l'image.Cette technique a l'avantage de ne pas nécessiter de recalculer l'image a chaque fois mais le défaut c'est qu'une fois enregistré l'image ne change plu*/
<img src="images/monimage.png" /> //Pour afficher l'image une fois enregistrer// 			

header("Content-type: image/png");
$image = imagecreate(200, 50);

$orange = imagecolorallocate($image, 255, 128, 0);/* Pour définir une couleur en php on doit utiliser la fonction imagecolorallocate et définir 4 paramètre: l'image sur laquelle on travail, la quantité de rouge,la quantité de vert et la 
													quantité de bleu.Cette fonction nous renvoie la couleur dans une variable on crée donc ainsi des  des sorte de variable couleurs.La premiere fois qu'on appel la fonction imagecolorallocate
													cette couleur devient la couleur de fond de l'image (ici le orange)*/
$bleu = imagecolorallocate($image, 0, 0, 255);
$bleuclair = imagecolorallocate($image, 156, 227, 254);
$noir = imagecolorallocate($image, 0, 0, 0);
$blanc = imagecolorallocate($image, 255, 255, 255);
imagestring($image, 4, 35, 15, "Salut les Zeros !", $blanc); /*Grace a la fonction imagestring,on peut écrire du texte sur notre image horizontalement, imagestringup pour l'écrire verticalement.Il faut indiquer 5 parametre : l'image ou on 
																doit mettre le text($image), la police (on doit mettre un nombre de 1=petit a 5=grand) il est aussi possible d'utiliser une police personalisé mais il faut avoir des police dans un format spécial,les coordonnées($x,$y) auxquelles on veut placer du texte.Il ne faut pas oublier que pour une image de 200 par 50 nos coordonnée s'arreteront a 199 et 49 comme on commence a compter de 0,ensuite le texte a afficher,et on lui applique une couleur(que l'on a créer avant)*/
imagepng($image);

ImageSetPixel ($image, $x, $y, $couleur); //Php permet aussi de créer des formes, avec la fonction ImageSetPixel, on peut créer un pixel,en indiquant 4 parametre : l'image,les coordonnées et la couleur de la meme maniere que vu précédemment//
ImageLine ($image, $x1, $y1, $x2, $y2, $couleur);// ImageLine permet de créer une ligne en indiquant la position des 2 points sur axe x et y //
ImageEllipse ($image, $x, $y, $largeur, $hauteur, $couleur);//ImageEllipse dessine une ellipse dont le centre se trouve au coordonnées x et y il faut aussi indiquer la largeur,la hauteur et la couleur//
ImageRectangle ($image, $x1, $y1, $x2, $y2, $couleur); //ImageRectangle dessine un rectangle, dont le coin superieur gauche est de coordonner x1 et y1 et celui en bas a droite x2 y2//

$points = array(10, 40, 120, 50, 160, 160); 
ImagePolygon ($image, $points, 3, $noir); /*ImagePolygon permet de créer un polygone ayant un nombre de point indiquer dans le 3 eme parametre(ici 3 c'est donc un triangle), l'array $points contient les coordonnée de tout les points du  												polygone dans l'ordre (x1,y1,x2,y2,x3,y3)*/		

imagecolortransparent($image, $orange);/*Avec la fonction imagecolortransparent on peut rendre une image transparente en indiquant la couleur qu'on veut rendre transparente.Attention cela ne marche que sur les images au format png et non sur 
										jpeg*/


header ("Content-type: image/jpeg"); // L'image que l'on va créer est un jpeg//

// On charge d'abord les images
$source = imagecreatefrompng("logo.png"); // Le logo est la source//
$destination = imagecreatefromjpeg("couchersoleil.jpg"); // La photo est la destination//

// Les fonctions imagesx et imagesy renvoient la largeur et la hauteur d'une image et la stocke dans les variables correspondante//
$largeur_source = imagesx($source);
$hauteur_source = imagesy($source);
$largeur_destination = imagesx($destination);
$hauteur_destination = imagesy($destination);

// On veut placer le logo en bas à droite, on calcule les coordonnées où on doit placer le logo sur la photo//
$destination_x = $largeur_destination - $largeur_source;
$destination_y =  $hauteur_destination - $hauteur_source;

/* La fonction imagecopymerge, permet de fusionner 2 image entre elle en indiquant plusieurs parametre : l'image qu'on va modifier,l'image qu'on va integrer,l'abscisse(axe x) a laquelle on désire placer le logo sur la photo,l'ordonnée(axe y)
a laquelle on désire placer le logo sur la photo,l'abscisse de la source(la fonction imagecopymerge permet de ne prendre qu'une partie de l'image de la source comme on prend tout le logo on met 0,ordonnée de la source pareil 0,la largeur de la source qui détermine quel partie de l'image source on va prendre (ici toute la largeur donc largeur_source),hauteur source pareil que largeur mais hauteur,le pourcentage de transparence du logo de 0(invisible) a 100(opaque) en général 60-70 est pas mal */
imagecopymerge($destination, $source, $destination_x, $destination_y, 0, 0, $largeur_source, $hauteur_source, 60);

// On affiche l'image de destination qui a été fusionnée avec le logo
imagejpeg($destination);



/*On peut aussi redimensionner une image grace a la fonction imagecopyresampled,c'est fonction est puissante mais lente elle demande énormément de travail au processeur,il est donc conseiller de ne pas l'afficher dans un header mais plutot de l'enregistrer sur le disque et de l'afficher ensuite dans le code html(avec <img/>).imagecopyresampled contient plusieurs paramètre : destination(l'image vide créer avec truecolor),la source(l'image dont on veux faire la miniature),l'abscisse(x) ou on veut placer notre miniature dans la destination (ici 0 comme il n'y aura qu'une seule image à l'interieur),l'ordonnée(y) ou on veut placer notre miniature dans la destination(ici 0),l'ascisse du point de la source (ici 0 on prend toute la source),ordonnée du point de la source (0),largeur de la miniature(un des paramètres les plus important, qui détermine la largeur de la miniature à créer),hauteur de la miniature,largeur source (ici on indique la largeur de notre source),hauteur source*/

$source = imagecreatefromjpeg("images/chat.jpg");
$destination = imagecreatetruecolor(200, 150);

$largeur_source = imagesx($source);
$hauteur_source = imagesy($source);
$largeur_destination = imagesx($destination);
$hauteur_destination = imagesy($destination);

imagecopyresampled($destination, $source, 0, 0, 0, 0, $largeur_destination, $hauteur_destination, $largeur_source, $hauteur_source);

imagejpeg($destination, "images/chat_mini.jpg");


?>