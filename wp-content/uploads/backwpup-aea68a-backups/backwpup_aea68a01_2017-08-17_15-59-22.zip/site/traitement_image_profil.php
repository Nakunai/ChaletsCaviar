<?php
session_start();

if(isset($_SESSION['id'],$_SESSION['pseudo']))
{
?>
<!DOCTYPE html>
	<html> 
    	<head lang="fr"> 
        	<meta charset="utf-8" />
        	<title>Cartomania</title>
       		<link rel="stylesheet" href="forumstyle2.css"/>
    	</head>
		
		<body>
		<?php
			if(isset($_FILES['envoi_image']) AND $_FILES['envoi_image']['error'] == 0)
			{
				if($_FILES['envoi_image']['size'] <= 1000000)
				{
					$infosFichier = pathinfo($_FILES['envoi_image']['name']);
					$extension_upload = $infosFichier['extension'];
					$extensions_autoriser = array('png');

					if(in_array($extension_upload,$extensions_autoriser))
					{
						move_uploaded_file($_FILES['envoi_image']['tmp_name'],'avatars/' . basename($_SESSION['id']. '.png'));
			
						$source = imagecreatefrompng('avatars/' .$_SESSION['id'].'.png');
						$destination = imagecreatetruecolor(100, 100);

						$largeur_source = imagesx($source);
						$hauteur_source = imagesy($source);
						$largeur_destination = imagesx($destination);
						$hauteur_destination = imagesy($destination);

						imagecopyresampled($destination, $source, 0, 0, 0, 0, $largeur_destination, $hauteur_destination, $largeur_source, $hauteur_source);
						imagepng($destination, 'avatars/' . $_SESSION['id'].'.png');
						header('Location: espace_membre.php');
					}
						
					else
					{
						echo 'Seulement le png !';
					}
				}

				else
				{
					echo 'Fichier trop gros !';
				}
			}

			?>

			<form method="post" enctype="multipart/form-data">
			<input type="file" name="envoi_image"/>
			<input type="submit" value="Envoyer !"/>
			</form>
		</body>
	</html>
<?php
}

else
{
	header('Location: connexion.php');
}
?>



