<?php 
session_start();
?>
<!DOCTYPE html>
<html> 
    <head lang="fr"> 
        <meta charset="utf-8" />
        <title>Cartomania</title>
        <link rel="stylesheet" href="forumstyle2.css"/>
    </head>    

    
    <body>
           <header>
            	<nav>
                    <a href="accueil.php" class="accueil_icone">Cartomania</a>
                    <div id="connexion_icone">
                        <?php
                            if(isset($_SESSION['id'], $_SESSION['pseudo'])) //
                            {
                                ?><a href="deconnexion.php">Se deconnecter</a><?php
                            }
                            else
                            {
                                ?><a href="inscription.php">Créer un compte</a><?php
                                ?><a href="connexion.php">Se connecter</a><?php 
                            }  
                        ?>
                    </div>
                </nav>
            </header>
            
            <section>
                <article>
                </article>
            </section>
    </body>
</html>