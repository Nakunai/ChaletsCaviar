<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>CIBLE</title>
    </head>
    
    <body>

    <p>Bonjour <?php echo htmlspecialchars($_POST['prenom']); ?> </p><!--htmlspecialchars est une fonction permettant d'annuler l'execution des balise html
    																	et les affiche seulement.Cela permet d'éviter que l'utilisateur profite de la faille
    																	XSS pour entre du html ou du script dans le formulaire.On peut aussi ecrire 
    																	strip_tags a la place, qui elle à l'inverse cache les balises-->

    <?php
    if(isset($_POST['vegetarien']))
    {
    	echo '<p>Vous êtes donc vegétarien</p>';
    }
    else
    {
    	echo'<p>Vous n\'êtes pas végétarien</p>';
    }
    ?>




    </body>
</html>    