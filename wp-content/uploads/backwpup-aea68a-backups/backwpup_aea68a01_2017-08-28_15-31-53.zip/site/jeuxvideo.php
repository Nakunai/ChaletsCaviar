<?php
$bdd = new PDO('mysql:host=localhost;dbname=test','root','', array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION)); /*Permet de faire la liaison avec la base de 
																données, on précise lhote,le nom de la base,identifiant,mot de passe .exception et errmode aide a 
																mieux répérer les erreurs.$bdd n'est pas vraiment une variable,c'est objet qui représente la
																connexion a la base de données,PDO est une extension orienté objet */
																

$reponse = $bdd->query('SELECT console, nom, prix FROM jeux_video WHERE console="NES" OR console="PC" ORDER BY nom'); /*query sert a faire une requete SQL.SELECT  
											demande a MySQL d'afficher ce que  contient une table,a la suite on  précise quels champs doivent etre récupéré dans cette table par exemple nom(ici * veut dire tout les champs),FROM est un mot qui fait la liaison entre le nom des champs et ceux de la table  qui se traduit par "dans",et enfin la table dans laquelle il faut piocher (ici jeux_video).On stocke tout ca dans une variable $reponse qui va représenter l'ensemble des données de la table jeux video.WHERE permet de filtrer les données ici par ex on va afficher seulement les console "NES" ou/et PC (grace a OR) ORDER BY permet de trier par nom de jeux ou par prix coissant par exemple.Si on rajoute DESC a la suite, ce seras par ordre décroissant.On peut aussi rajouter LIMIT pour limiter le nombre d'entrer afficher en lui indiquant une valeurs (3par exemple on peut aussi indiquer deux valeurs séparer par une virgule.la premiere diras par quel entrée on commencera et la deuxieme combien on en affiche).Il faut que chaque mot-clés(SELECT,FROM,...)soit bien écris dans cette ordre */

while($donnees = $reponse->fetch()) /*On affiche le résultat de la requete avec une boucle while.Pour organiser les donnée de la requête, fetch va récuperer une 	
									ligne a chaque tour de boucle et les organise dans l'array $donnees */
{

	echo '<p>' . $donnees['console'] .' - ' . $donnees['nom'] . ' - ' . $donnees['prix'] . ' euros. <p>';

}

$reponse->closeCursor(); //Permet de fermer le travail sur cette requete et ainsi passer a la suivante//

$bdd = new PDO('mysql:host=localhost;dbname=test','root','', array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
$requete = $bdd->prepare('INSERT INTO jeux_video(nom,posesseur) VALUES(?,?)'); /*INSERT INTO permet d'inserer une nouvelle entré dans une table.L'utilisateur 
																				pourras ainsi créer sa propre ligne commes le VALUES contient des ? attention a bien
																				executer les $_GET dans le meme ordre.On peut aussi le faire depuis phpMyadmin*/
	$requete->execute(array($_GET['nom'], $_GET['posesseur']));

$bdd = new PDO('mysql:host=localhost;dbname=test','root','', array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
$requete = $bdd->prepare('UPDATE jeux_video SET possesseur = ?  WHERE = ?');/*UPDATE permet de modifier une ligne existante.SET sépare le nom de la table
																			des champs a modifier et WHERE permet de dire a MySQL quel entrée doit etre modifié
																			(par ex : WHERE ID=51*/

	$requete->execute(array($_GET['possesseur'], $_GET['nom']));

$requete = $bdd->prepare('DELETE FROM jeux_video WHERE ID = ?');/*DELETE permet de supprimer une entrer(ou plusieurs) FROM désigne dans quel table et WHERE quel 
																ligne seras supprimer par exemple */
$requete->execute(array($_GET['ID']));



SELECT j.nom AS nom_jeu, p.prenom AS prenom_proprietaire /*Ceci est une jointure interne avec WHERE(ancienne syntaxe),une jointure interne ne récupère que les données qui ont une correspondance entre les 2 tables(par 
											exemple ici si on avais un proprietaire
											sans jeuxvideo, il n'apparaitrait pas.Ici le champs nom apparait dans la table jeux_video mais aussi dans proprietaire,c'est ce qu'on appelle une colonne ambigue car sql ne sait pas quoi récuperer
											le nom du jeu ou du proprietaire.Il faut donc placer le nom de chaque table séparer par un point devant le champs en question(il n'y a pas de colonne ambigue au niveau du prénom mais ca permet
											d'etre un peu plus compréhensible).On indique les 2 table dans la clause FROM et enfin on fais la liaison grace a WHERE en indiquant la corespondance entre les 2 tables (ici ID_proprietaire dans la
											table jeux_video est = a ID dans la table proprietaires).Il est fortement conseiller d'utiliser des alias(AS) lorsque l'on fait des jointure cela permet de donner un nom plus clair aux champs que l'on récupère.Il est aussi conseiller dans mettre un pour les table afin de rendre leurs noms plus court(on leurs met seulement 1-2 lettre).Il faut savoir aussi que AS est facultatif les développeurs ont tendance à l'enlever on peut donc l'enlever du code) */		
FROM proprietaires AS p, jeux_video AS j
WHERE j.ID_proprietaires = p.ID


SELECT j.nom AS nom_jeu, p.prenom AS prenom_proprietaire /*Ceci est une jointure interne avec JOIN(nouvelle syntaxe conseillé), même fonctionnement sauf que cette fois on récupère les donnée de la table principale(p) avec FROM,INNER JOIN fait
														la jointure interne avec une autre table(j)et on fait la liaison avec ON.On peut aussi rajouter (WHERE, ORDER BY, ou LIMIT par exemple pour affiner un peu plus la requête) mais il faudra les placer a la suite après le ON (ex : SELECT j.nom AS nom_jeu, p.prenom AS prenom_proprietaire FROM proprietaire AS p INNER JOIN jeux_video AS j ON j.ID_proprietaires = p.ID WHERE j.console= 'PC' ORDER BY prix DESC LIMIT 0, 5)*/
FROM proprietaire AS p
INNER JOIN jeux_video AS j
ON j.ID_proprietaires = p.ID


SELECT j.nom AS nom.jeu, p.prenom AS prenom_proprietaire/*Ceci est une jointure externe(elle n'a qu'une seul syntaxe), une jointure externe récupère toute les donnée même celle qui n'on pas de corespondance entre elle(par exemple si un 
														proprietaire n'a pas de jeux il sera quand meme dans la requete mais aura une valeur NULL sur son jeu)pour faire une requete externe on remplace le INNER JOIN par LEFT JOIN ou RIGHT JOIN,si on utilise LEFT JOIN on récupera tout le contenu de la table de gauche (ici proprietaire) même ceux qui n'ont pas d'équivalence dans la table jeux_video(un proprietaire sans jeux) et si on utilise RIGHT JOIN on récupera tout le contenu de la table de droite (ici jeux_video) meme ceux qui n'ont pas d'équivalence dans la table proprietaire(un jeu sans proprietaire)*/
FROM proprietaire AS p
LEFT JOIN jeux_video AS j
ON j.ID_proprietaires = p.ID





?>