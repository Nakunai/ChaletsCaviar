<?php
if(isset($_POST['pseudo']))
        {
            $requete = $bdd->prepare('SELECT pseudo FROM membres WHERE pseudo = ?');
            $requete->execute(array($_POST['pseudo']));
            $donnees = $requete->fetch();
            $requete->closeCursor();
            
            if(empty($donnees['pseudo']))
            {
                    
                if(preg_match('#^[a-zA-Z0-9_-]{1,9}$#', $_POST['pseudo']))
                {
                    if(isset($_POST['pass'], $_POST['pass_confirme']) && $_POST['pass'] == $_POST['pass_confirme'])
                    {
                        if(preg_match('#^[a-zA-Z0-9_-]{6,}$#', $_POST['pass']))
                        {
                            $pass_hache = sha1($_POST['pass']);
                            if(isset($_POST['email']))
                            {
                                if(preg_match('#^[a-z0-9._-]+@[a-z0-9._-]{2,}\.[a-z]{2,4}$#', $_POST['email']))
                                {
                                    $pseudo = htmlspecialchars($_POST['pseudo']);
                                    $pass_hache = htmlspecialchars($pass_hache);
                                    $email = htmlspecialchars($_POST['email']);
                                    $req = $bdd->prepare('INSERT INTO membres(pseudo,pass,email,date_inscription)VALUES(:pseudo,:pass,:email,CURDATE())');
                                    $req->execute(array('pseudo' => $pseudo,'pass' => $pass_hache, 'email' => $email));
                                    $req->closeCursor();
                                    header('Location: connexion.php');

                                }
                        
                                else
                                {
                                    ?><span id="erreur_mail">Email invalide !</span><?php
                                }
                        }
                        else
                        {
                            ?><span id="erreur_pass1">Mot de passe invalide !</span><?php
                        }
                    }
                    
                    elseif($_POST['pass'] !== $_POST['pass_confirme'])
                    {
                        ?><span id="erreur_pass">Les deux mots de passe sont différent, réessayer !</span><?php
                    }
                }
                else
                {
                    ?><span id="pseudo_exist">Pseudo invalide !</span><?php
                }
            }

            else
            {
                ?><span id="erreur_pseudo">Ce pseudo existe deja !</span><?php
            }
        }
        ?>