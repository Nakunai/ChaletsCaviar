<header>
        <div id="titre_principal">
            <div id="logo">
            	<img src="images/zozor_logo.png" alt="Logo de Zozor" />
            	<h1>Zozor</h1>    
        	</div>
        	<h2>Carnets de voyage</h2>
        </div>
<nav>
   	<ul>
        <li><a href="#">Accueil</a></li>
        <li><a href="#">Blog</a></li>
        <li><a href="#">CV</a></li>
        <li><a href="#">Contact</a></li>
    </ul>
</nav>

</header>
