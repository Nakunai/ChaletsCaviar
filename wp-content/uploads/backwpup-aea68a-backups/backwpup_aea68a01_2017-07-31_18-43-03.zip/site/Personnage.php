<?php
class Personnage
{
	private $_degats;
	private $_experience;
	private $_force;
	
	const FORCE_PETITE = 20;
	const FORCE_MOYENNE = 50;
	const FORCE_GRANDE = 80;

	public function __construct($forceInitiale)
	{
		$this->setForce($forceInitiale);
		
	}
	
	public function frapper(Personnage $persoAFrapper)
	{
		$persoAFrapper->_degats += $this->_force;
	}

	public function gagnerExperience()
	{
		$this->_experience++;
	}

	public function degats()
	{
		return $this->_degats;
	}

	public function experience()
	{
		return $this->_experience;
	}

	public function force()
	{
		return $this->_force;
	}

	public function setDegats($degats)
	{
		if(!is_int($degats))
		{
			trigger_error('Les degats du personne doivent être un nombre entier !');
			return;
		}

		if($degats > 100)
		{
			trigger_error('Les degats du personnage ne peuvent pas dépasser 100 ! ');
			return;
		}

		$this->_degats = $degats;
	}

	public function setForce($force)
	{
		if(in_array($force, [self::FORCE_PETITE, self::FORCE_MOYENNE, self::FORCE_GRANDE]))
		{
			$this->_force = $force;
		}
	}
	
	public function setExperience($experience)
	{
		if(!is_int($experience))
		{
			trigger_error('L\'experience du personnage doit etre un nombre entier !', E_USER_WARNING);
			return;
		}

		if($experience > 100)
		{
			trigger_error('L\'experience du personnage ne peut pas dépasser 100 !', E_USER_WARNING);
			return;
		}

		$this->_experience = $experience;
	}
}

?>