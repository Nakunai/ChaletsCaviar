<?php

if(isset($_POST['texte']))
{
	$texte = stripcslashes($_POST['texte']);
	$texte = htmlspecialchars($texte);
	$texte = nl2br($texte);

	$texte = preg_replace('#\[b\](.+)\[/b\]#isU', '<strong>$1</strong>', $texte);
	$texte = preg_replace('#\[b\](.+)\[/b\]#isU', '<em>$1</em>', $texte);
	$texte = preg_replace('#\[color=(blue|red|green|purple|olive)\](.+)\[/color\]#isU', '<span style="color:$1">$2</span>', $texte);
	$texte = preg_replace('#http://[a-z0-9._/-]+#i', '<a href="$0">$0</a>', $texte);

	echo $texte;

}

?>
<form method="post">
<p>
    <label for="texte">Votre message </label><br />
    <textarea id="texte" name="texte" cols="50" rows="8"></textarea><br />
    <input type="submit" value="Envoyer" />
</p>
</form>