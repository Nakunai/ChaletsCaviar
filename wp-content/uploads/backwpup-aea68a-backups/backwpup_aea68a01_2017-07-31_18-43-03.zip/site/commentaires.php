<!DOCTYPE html>
<html lang="fr">
    <head>
        <meta charset="utf-8" />
        <title>Mon blog</title>
    <link href="styleblog.css" rel="stylesheet" /> 
    </head>
 
    <body>
        <h1>Mon super blog !</h1>
        <a href="index.php">Retour à la liste des billets</a>

        <?php include("connexion_sql.php");
            
        $requete = $bdd->prepare('SELECT id,titre,contenu,DATE_FORMAT(date_creation, \'%d/%m/%Y à %Hh%imin%ss\') AS date_creation_fr FROM billets WHERE id=?');
        $requete->execute(array($_GET['billet']));
        $donnees = $requete->fetch();
        if(empty($donnees))
        {
            echo 'Erreur ce billet n\'existe pas !';
        }
        
        else
        {
        
        include("affiche_billet.php"); ?>
            </p>
        </div>
         
        <h2>Commentaires</h2>

        <?php
        $requete->closeCursor();

        
        $req = $bdd->prepare('SELECT auteur,commentaire,DATE_FORMAT(date_commentaire, \'%d/%m/%Y à %Hh%imin%ss\') AS date_commentaire_fr FROM commentaires WHERE id_billet=? ORDER BY date_commentaire DESC LIMIT 0,5');
        $req->execute(array($_GET['billet']));

        while($donnees = $req->fetch())
        {
            ?>
                <p><strong><?php echo nl2br(htmlspecialchars($donnees['auteur'])); ?></strong> le <?php echo $donnees['date_commentaire_fr']; ?></p>
                <p><?php echo nl2br(htmlspecialchars($donnees['commentaire'])); ?></p>
            <?php
        }

        $req->closeCursor();
        ?>
        <p>
        <form method="post" action="commentaires_post.php?billet=<?php echo $_GET['billet']; ; ?>">
            <label for="pseudo">Pseudo</label>
            <input type="text" name="pseudo" id="pseudo"/>
            <label for="message">Message</label>
            <input type="text" name="message" id="message"/>
            <input type="submit" value="Envoyer !"/>
        </form> 
        </p>
        <?php
        }
        ?>
    </body>
</html>