<?php


?>
<!DOCTYPE html>
<html lang="fr">
    <head>
        <meta charset="utf-8" />
        <link rel="stylesheet" href="stylezozor.css" />
        <title>MiniChat</title>
    </head>
    
    <body>

    <style>
    	form
    	{
    		text-align: center;
    	}


    </style>
 	
    <form action="minichat_post.php" method="post">
        <p>
        <label for="pseudo">Pseudo :</label>
        <input type="text" name="pseudo" id="pseudo" value = <?php if(isset($_COOKIE['pseudo']))
            {
            
                echo htmlspecialchars($_COOKIE['pseudo']);

            }   
            
            ?> ></br>
        <label for="message">Message :</label>
        <input type="text" name="message" id="message" autofocus/></br>
        <input type="submit" value="Envoyer !"/>
        <a href="minichat.php">Rafraichir</a>
        </p>
    </form>
   
    
    
    
    
    <?php
    
    
try
{
        
    $bdd = new PDO('mysql:host=localhost;dbname=test;charsetutf8','root','',array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
   
}
    
catch(Exception $e)

{
        die('Erreur : '.$e->getMessage());
}



$reponse = $bdd->query('SELECT pseudo, message FROM minichat ORDER BY ID DESC LIMIT 0, 10');
    
    
    

 
    
    while($donnees = $reponse->fetch())
    {
        echo '<p><strong>' . htmlspecialchars($donnees['pseudo']) . '</strong> : ' . htmlspecialchars($donnees['message']) . '</p>';
    }

    $reponse->closeCursor();

  ?>
    
    </body>
</html>

<?php
setcookie('pseudo',$_POST['pseudo'], time() + 365*24*3600, null, null, false, true);
    

    if(isset($_POST['pseudo'], $_POST['message']) && $_POST['pseudo'] !== '' && $_POST['message'] !== '')
    {

    
    
        try
        {
            $bdd = new PDO('mysql:host=localhost;dbname=test;charset=utf-8','root','', array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
            $requete = $bdd->prepare('INSERT INTO minichat(pseudo, message) VALUES(?, ?)');
            $requete->execute(array($_POST['pseudo'], $_POST['message']));
            header('Location: minichat.php');
        }

        catch(Exception $e)
        {
            die('Erreur : '.$e->getMessage());
        }
    }



header('Location: minichat.php');


?>
