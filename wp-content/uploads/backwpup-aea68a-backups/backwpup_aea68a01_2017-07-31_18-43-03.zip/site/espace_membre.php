<?php
session_start();

if(isset($_SESSION['id'], $_SESSION['pseudo']))
{
	?>
<!DOCTYPE html>
	<html> 
    	<head lang="fr"> 
        	<meta charset="utf-8" />
        	<title>Cartomania</title>
       		<link rel="stylesheet" href="forumstyle2.css"/>
    	</head>    

    
   		<body>
         		<header>
            			<nav>
                    		<a href="accueil.php" class="accueil_icone">Cartomania</a>
                    		<div id="connexion_icone">
                        		<a href="deconnexion.php">Se deconnecter</a>
                    		</div>
                		</nav>
           	</header>
            <div id="bloc_page">
                  <div id="top">
                    <div id="ajout_image_profil">
                      <img src='avatars/<?php echo $_SESSION['id'];?>.png' alt="avatar" id="image_profil"/><br/>
                      <a href="traitement_image_profil.php">Ajouter un avatar</a>
                  </div>
                  <h2><?php echo $_SESSION['pseudo'];?></h2>
                </div>
                <section>
                  <form method="post">
                    <label for="nom">Nom :</label>
                    <input type="text" name="nom" id="nom"/><br/>
                    <label for="prenom">Prénom :</label>
                    <input type="text" name="prenom" id="prenom"/><br/>
                    <label for="age">Age :</label>
                    <input type="text" name="age" id="age"/><br/>
                    <label for="adresse">Adresse :</label>
                    <input type="text" name="adresse" id="adresse"/><br/>
                    <label for="postal">Code Postal :</label>
                    <input type="text" name="postal" id="postal"/><br/>
                    <label for="ville">Ville :</label>
                    <input type="text" name="ville" id="ville"/><br/>
                    <input type="submit" value="Enregistrer" id="enregistrer"/>
                  </form>
                </section>
            </div>
      </body>
	</html>
<?php
}

else
{
	header('Location: connexion.php');
}
?>