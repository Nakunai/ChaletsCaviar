<!DOCTYPE html>
<html lang="fr">
    <head>
        <meta charset="utf-8" />
        <title>Mon blog</title>
    <link href="styleblog.css" rel="stylesheet" /> 
    </head>
        
    <body>
        <h1>Mon super blog !</h1>
        <p>Derniers billets du blog :</p>
        
       <?php include("connexion_sql.php"); ?>

        <?php
        $reponse = $bdd->query('SELECT id,titre,contenu,DATE_FORMAT(date_creation, \'%d/%m/%Y à %Hh%imin%ss\') AS date_creation_fr FROM billets ORDER BY date_creation DESC LIMIT 0, 5');

        while($donnees = $reponse->fetch())
        {
            ?>
               <?php include("affiche_billet.php"); ?>
                        <a href="commentaires.php?billet=<?php echo $donnees['id']; ?>">Commentaires</a>
                        
                    </p>
                </div>
            <?php
        }
        
        $reponse->closeCursor();
        ?>
    </body>
</html>