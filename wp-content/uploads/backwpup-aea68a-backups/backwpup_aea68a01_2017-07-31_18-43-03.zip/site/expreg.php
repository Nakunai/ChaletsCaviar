<?php

if (preg_match('#guitare#i', 'j\'aime la guitare')) /*Les expressions régulières constituent un système très puissant et très rapide pour faire des recherches dans des chaînes de caractères (des phrases, par exemple). C'est une sorte de 
													fonctionnalité Rechercher/Remplacer très poussée.Il existe 2 type d'expression régulière : POSIX et PCRE, POSIX est un langage d'expression régulière mis en avant par PHP qui se veut
													plus simple que PCRE mais son gros défaut est qu'il est plus lent.Les expression régulière de PCRE, sont issu d'un autre langage (le Pearl), qui est un peu plus complexe mais plus rapide et performant que POSIX.On utilisera donc PCRE.La fonction preg_match est une fonction utilisant le PCRE pour faire une recherche et elle renvoi un boolen(true/false).Il faut indiquer 2 information a la fonction preg_match : la regex(l'expression régulière)qui est délimiter par des délimiteur(ici des #), et la chaine de caractère ou on fais la recherche.On peut aussi rajouter des options après ces délimiteurs,par exemple en rajoutant i après le #, la regex ne fera plu attention a la casse(ex:regex GUITARE chaine aime la guitare le boolen sera vrai*/

{
	echo 'VRAI';
}

else
{
	echo 'FAUX';
}

if(preg_match('#guitare|banjo#', 'la guitare c\'est la vie')) /* Notre regex peut avoir plusieur posibilité grace a | (qui signifie ou),ce qui permet ici par exemple de vérifier la présence du mot guitare OU banjo dans la phrase,si c'est le 
																cas c'est vrai */
{
	echo 'VRAI';
}

else
{
	echo 'FAUX';
}

if(preg_match('#chat$#', 'Les yeux du chat')) /*On peut etre encore plus précis dans notre regex, si on veut qu'un chaine de caractere se finisse par chat, on ajoute un $ apres ce mot dans la regex.Si on veut au contraire que celui ci soit au 													début on met un ^ devant ce mot dans la regex (par exemple : #^chat#)*/  
{
	echo 'VRAI';
}

else
{
	echo 'FAUX';
}

if(preg_match('#p[hou]p#', 'PHP Les expressions pHp')) /* On peut aussi placer ce qu'on appelle une classe de caractere entre [], ce qui signifie qu'une des lettre à l'interieur peut convenir dans la chaine, par exemple ici : php OU pop OU 
														pup.On peut aussi autoriser une plage de caractere grace au intervalles de classes, par exemple de a a z [a-z] ou pour majuscule [A-Z] ou les deux [a-zA-Z].Ca marche aussi pour les nombres, par exemple [0-9], ici on acceptera n'importe quel chiffre entre 0 et 9,on peut mélanger les deux [a-z0-9] */
{
	echo 'VRAI';
}

else
{
	echo 'FAUX';
}

if(preg_match('#p[^1-6]#', 'Encore du php ?...')) /* En rajoutant ^ dans notre classe de caractère on dis qu'on ne VEUT PAS par exemple d'un chiffre entre 1 et 6*/
{
	echo 'VRAI';
}

else
{
	echo 'FAUX';
}

if(preg_match('#Ay(ay)?#', 'Ayayay')) /*On peut aussi utiliser des quantificateurs, qui permette de dire combien de fois peut se repeter un caractere ou une suite de caractere. ? indique que le caractere ou la chaine est facultative,elle peut 
										y etre 0 ou 1 fois.On peut utiliser les () pour cibler une certaine partie.*/  
{
	echo 'VRAI';
}

else
{
	echo 'FAUX';
}

if(preg_match('#Ay(ay)+#', 'Ayayay')) // Avec le + le caractere ou la chaine est obligatoire et doit etre présent 1 fois ou plus //


if(preg_match('#Ay(ay)*#', 'Ayayay')) // Avec le * le caractere ou la chaine est facultative, et peut etre présent 0,1 ou plusieurs fois// 

if(preg_match('#^Ay(ay){3}$#', 'Ayayayay')) /* On peut etre plus précis grace au {}, en indiquant un nombre de repetition ici ay doit etre repeter 3 fois pas plus pas moins(si on ne met pas ^ et # pour dire qu'on commence par ca et on finis 
											par ca, il va compter jusqua 3 et si il y a 3 ou plus la condition sera valider),  .On peut aussi dire qu'on veut entre 3 et 5 repetition en écrivant{3,5}.Ou
											si par exemple on a {3,} sans 2 eme chiffre apres la virgule , alors on autorise entre 3 et un infini de répetition*/


if(preg_match('#.{3}#', 'a')) /* Le point (.), signifie qu'il peut y avoir n'importe quel caractere a cette encdroit (meme les espaces).Ici avec le {3}, on veut n'importe quel caractere mais on en veux 3.Tout les caractere spéciaux vu avant
								s'apelle des metacaractere(# ! ^ $ ( ) [ ] { } ? + * . \ |) ce sont des caractere qui on un role ou un sens particulier*/

if(preg_match('#\.#', '.')) // Si on veut rechercher un de ces metacaractere, il faut l'échapée grace a \ qui va annuler la symbolique du caractere //


if(preg_match('#[a-z?+*{}]#', '{}')) /* Si on recherche des metacaractere dans une classe, plu besoin du \ pour annuler la symbolique.Il y a 3 cas particulier : le # pour l'utiliser on met \ devant (\#), le ] pour l'utiliser on met aussi un \ et pour le tiret (-) on le met soit au début soit a la fin de la classe (par ex : a-z0-9-) */

/* Il existe aussi des classes abreger (ou des racourci) : \d indique un chiffre (ca revient a taper [0-9]), \D indique ce qui n'est pas un chiffre (revient a taper[^0-9]), \w indique un caractere alphanumerique ou un tiret de soulignement cela sorrespond a [a-z0-9_], \W indique ce qui n'est pas un mot ca revient a taper [^a-z0-9_], \t indique une tabulation, \n indique une nouvelle ligne, \r indique un retour chariot, \s indique un espace blanc, \S indique ce qui n'est pas un espace blanc (\t \n \r), et enfin le . qui indique n'importe quel caractere ou pour ainsi dire tout (tout sauf les entrées (\n) pour faire en sorte que le point indique tout meme les entrées, il faut lui rajouter l'option s ex: #[0-9]-.#s)*/


?>
<p>
<?php
if(isset($_POST['mail']))
{
	$_POST['mail'] = htmlspecialchars($_POST['mail']);
	
	if(preg_match('#^[a-z0-9._-]+@[a-z0-9._-]{2,}\.[a-z]{2,4}$#', $_POST['mail'] )) // Voila un exemple de code pour vérifier une adresse mail par exemple//
	{
		echo 'L\'adresse à bien était enregistré';
	}	

	else
	{
		echo 'Erreur ce mail n\'est pas valide !';
	}
}
?>
</p>

<form method="post">
	<p>		
		<label for="telephone">Votre adresse email</label>
		<input id="mail" name="mail"/>
		<input type="submit" value="Envoyer !"/>
	</p>
</form>



<?php

SELECT nom FROM visiteurs WHERE ip REGEXP '^84\.254(\.[0-9]{1,3}){2}$' /*On peut aussi utiliser les expression réguliere avec MySql a la seul difference que MySql ne comprend que le POSIX et pas le PCRE, il faut donc retenir qu'en POSIX il 
																		n'y a pas de délimiteur ni d'option (donc pas de # et ni de i ou de s etc...) et il n'y a pas de classe de caractere (donc pas de \n par exemple) apart le point .*/


?>
<p>
<?php

if(isset($_POST['message']))
{
	$texte = preg_replace('#\[b\](.+)\[/b\]#i', '<strong>$1</strong>', $_POST['message']); /* Avec la fonction preg_replace,on peut faire une capture de chaine et faire un remplacement,il faut indiquer 3 parametre : la regex(on met entre () 
																							la partie qu'on va remplacer ,le texte de remplacement qu'on symbolise par une variable avec un nombre pouvant aller de $1 a $99(pour savoir quels nombre il faut indiquer il suffit de compter les () de gauche a droite en sachant aussi que $0 englobe toute la regex), et enfin le texte dans lequel on fait la recherche/remplacement.Si on veux qu'une parenthese ne soit plus capturante il faut qu'elle commence par ?: (exemple : (#(anti)co(?:nsti)(tu(tion)nelle)ment# ici la seconde parenthese n'est plus capturante et donc le $2 s'applique au suivant*/

	echo $texte;
}
?>
</p>

<form method="post">
	<p>		
		<label for="message">Message</label>
		<input id="message" name="message"/>
		<input type="submit" value="Envoyer !"/>
	</p>
</form>

<?php
if(isset($_POST['texte']))
{
	$texte = stripcslashes($_POST['texte']); //On enleve les slash qui se serait rajouter automatiquement //
	$texte = htmlspecialchars($texte); // On rend les balise htlm inofensive//
	$texte = nl2br($texte); // On crée des br pour conserver les retour a la lignes//

	$texte = preg_replace('#\[b\](.+)\[/b\]#isU', '<strong>$1</strong>', $texte); /* Voici un parser, qui sert a transformer le texte envoyer par le visiteur en un texte inofensif grace a htlmspecialchars mais qui accepte du bbcode.
																					l'option U sert a ce que notre regex s'arrete au premier [/b] est non au tout dernier,cela évite qu'elle se mélange en quelque sorte.l'option s est utiliser
																					pour que le point fonctionne aussi pour les retour a la ligne (pour avoir un texte en gras sur plusieurs lignes par exemple) et l'option i pour accepter majuscule/minuscule */ 
	$texte = preg_replace('#\[b\](.+)\[/b\]#isU', '<em>$1</em>', $texte); //Bbcode pour italique//
	$texte = preg_replace('#\[color=(blue|red|green|purple|olive)\](.+)\[/color\]#isU', '<span style="color:$1">$2</span>', $texte); //Bbcode pour la couleur//
	$texte = preg_replace('#http://[a-z0-9._/-]+#i', '<a href="$0">$0</a>', $texte); //On rend les liens cliquable//

	echo $texte;

}

?>
<form method="post">
<p>
    <label for="texte">Votre message </label><br />
    <textarea id="texte" name="texte" cols="50" rows="8"></textarea><br />
    <input type="submit" value="Envoyer" />
</p>
</form>

?>