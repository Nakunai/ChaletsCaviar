<?php include("connexion_sql.php");




$requete = $bdd->prepare('INSERT INTO commentaires(id_billet,auteur,commentaire,date_commentaire) VALUES(?,?,?,NOW())');
$requete->execute(array($_GET['billet'], $_POST['pseudo'], $_POST['message']));

header('Location: commentaires.php?billet=' . $_GET['billet']);

$requete->closeCursor();

?>