<?php 
session_start(); /*Permet de démarrer le stysteme de session, cela doit etre écris avant tout le code. 
					session_destroy()  : ferme la session du visiteur. Cette fonction est automatiquement appelée lorsque le visiteur ne charge plus de page de votre site pendant plusieurs minutes (c'est le timeout), mais vous pouvez aussi créer une page « Déconnexion » si le visiteur souhaite se déconnecter manuellement.A repeter sur chaque pages comme les cookie*/
setcookie('pseudo','Kriyu', time() + 365*24*3600, null, null, false, true); /*Permet de créer un cookie il faut indiquer 3 paramètres : son nom, sa valeur, et sa 
																			date d'expiration
													sous forme de timestamp, ici il est valable 1ans, un cookie comme une session doit etre écris tout au début !
													On stocke généralement une information par cookie.Le paramètre true permert d'activer l'option httponly
													qui sécurise les cookie,cela réduit drastiquement le risque de faille XSS comme htmlspecialchars*/
setcookie('pays', 'France', time() + 365*24*3600, null, null, false, true);//On peut modifier un cookie existant en en recréant un nouveau avec le meme nom//
$_SESSION['prenom'] = 'Jean'; //Variable superglobale de session qui seront conservé sur toute les pages//
$_SESSION['nom'] = 'Dupont';
$_SESSION['age'] = 24;
?>

<!DOCTYPE html>

<html>
    <head>
        <meta charset="utf-8" />
        <title>Bonjour</title>
    </head>
    
    <body>

    	<p>
    		<?php 
    		if(isset($_GET['nom']) AND isset($_GET['prenom']) AND isset($_GET['repeter']))//isset est une fonction permettant de vérifier si une variable existe//
    		{
    			$nbRepetitions = (int) $_GET['repeter']; /*Int convertis la variable en type entier.on lis le code de droite a gauche, int est comme un tuyau de 
    														conversion.On appelle ca le transtypage.Il existe plusieurs type de champs : int pour les nombres entier,varchar pour les text court,text pour les texte long, etc...*/
    			
    			if(nbRepetitions < 100)
    			{
	    			for($repetition = 0; $repetition < $nbRepetitions; $repetition++)
	    			 {
	    			 
	    			 	echo '<p> Bonjour' . $_GET['nom'] . ' '. $_GET['prenom'] . '</p>'; /*On peut retrouver les paramètre envoyer dans 
	    																				l'URL grâce a un tableau associatif	nommé $GET il ya aussi $_POST
	    																				qui récupère les donnée des formulaire, ce sont des variables
	    																				superglobales*/
	    			 }																
    			}
    		}
    		else
    		{
    			echo 'Pas de nom ou de prénom défini ou de répétition !';
    		}
    		?>

    		<a href="sessionpage.php">Lien</a>
    	</p>

   	</body>

</html>