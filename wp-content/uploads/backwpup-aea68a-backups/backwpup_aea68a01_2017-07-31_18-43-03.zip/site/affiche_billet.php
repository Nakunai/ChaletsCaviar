<div class="news">
                 	<h3>
                        <?php echo nl2br(htmlspecialchars($donnees['titre'])) . 'le ' . $donnees['date_creation_fr']; ?>
                    </h3>
                    <p>
                        <?php echo nl2br(htmlspecialchars($donnees['contenu'])); ?>
                    <br/>