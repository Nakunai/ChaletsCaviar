<!DOCTYPE html>
<html lang="fr">
    <head>
        <meta charset="utf-8" />
        <link rel="stylesheet" href="stylezozor.css" />
        <title>Page1</title>
    </head>

    <body>
        <div id="bloc_page">
        	<?php include('entete.php'); ?>
        	<div id="banniere_image">
                <div id="banniere_description">
                    Retour sur mes vacances aux États-Unis...
                    <a href="#" class="bouton_rouge">Voir l'article <img src="images/flecheblanchedroite.png" alt=""/></a>
                </div>
            </div>
        	
        	<section>
            	<article>
                </article>
                <aside>
                </aside>
            </section>
			<?php include('pieddepage.php'); ?>
		</div>
	</body>		
</html>