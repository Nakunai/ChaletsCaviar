<?php 
session_start();
setcookie('pseudo','Kriyu', time() + 365*24*3600, null, null, false, true);
setcookie('pays', 'France', time() + 365*24*3600, null, null, false, true);

?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>Titre de ma page</title>
    </head>
    <body>

    <?php
  
    echo ' Salut ' . $_SESSION['prenom'] . ' !';
    echo ' Ton pseudo c\'est ' . $_COOKIE['pseudo'] . ' !';
    echo ' Et ton pays est ' . $_COOKIE['pays'] . ' !'; 
    ?>
    </body>