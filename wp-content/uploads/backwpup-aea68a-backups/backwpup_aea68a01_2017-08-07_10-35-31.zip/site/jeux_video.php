<?php

if(isset($_GET['console']))
{

	$bdd = new PDO('mysql:host=localhost;dbname=test','root','', array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));		
	$requete = $bdd->prepare('SELECT * FROM jeux_video WHERE console = ? '); //Avec prepare on peut preparer une requete sans la partie variable //
	$requete->execute(array($_GET['console' ])); //On execute la requete a l'aide des parametre que l'on indique sous forme d'array 
	while($donnees = $requete->fetch())
	{
		echo '<p>' . $donnees['console'] .' - ' . $donnees['nom'] . ' - ' . $donnees['prix'] . ' euros. <p>';
	}

	

}




$bdd = new PDO('mysql:host=localhost;dbname=test','root','', array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));		
	$requete = $bdd->prepare('SELECT UPPER(nom) AS nom_majuscule,console,prix FROM jeux_video WHERE console = ?'); /*UPPER est une fonction scalaire SQL, elle permet de convertir l'intégralité d'un champ en majuscule.Elle crée une sorte de  
																					 					"champ virtuel",qui n'existe que le temps de la requête,il est conseillé de donnée un nom a ce champ grâce a un alias(AS).On peut ensuite
																					 					écrire le contenu des autres champs comme avant sans forcément leurs appliquer de fonction en séparant par des ,  
																					 					Il y a aussi LOWER pareil que UPPER sauf que ici elle permet de convertir l'intégralité d'un champ en miniscule.LENGTH qui permet de
																					 					récupérer la longueur d'un champ ex : MARIO(la fonction renvoi 5)*.ROUND qui permet d'arrondir un nombre décimal (par ex : si un jeu coûte 25,86999 euros, on obtiendra la valeur 25,87 euros il faut indiquer deux parametre: le nom du champ à arrondir et le nombre de chiffres après la virgule que l'on souhaite obtenir.Les fonctions scalaire SQL sont des fonctions qui modifie les valeurs une a une contrairement au fonctions d'agrégat SQL qui font des opération sur plusieurs entrées pour retourné une seul valeur*/
	$requete->execute(array($_GET['console' ])); 
	while($donnees = $requete->fetch())
	{
		echo '<p>' . $donnees['console'] .' - ' . $donnees['nom_majuscule'] . ' - ' . $donnees['prix'] . ' euros. <p>'; //Le champ ne s'apelle plu nom mais nom_majuscule //
	}
$bdd = new PDO('mysql:host=localhost;dbname=test','root','', array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));		
	$requete = $bdd->prepare('SELECT AVG(prix) AS prix_moyen FROM jeux_video WHERE console="PC"'); /*AVG est une fonction d'agrégat, elle calcule la moyenne d'un champ contenant des nombres(par exemple la moyenne de tout les prix),ducoup elle 
																									ne renvois qu'une seule entrée.On ne peut sélectionner que 1 champs par agrégat contrairement aux scalaire ou on a pu en récupérer plusieurs , il y a aussi SUM qui va calculer la somme par exemple des prix de tout les jeux vidéo (par ex:20+30+50=100),il y a aussi MAX qui retourne la valeur maximale (par exemple le jeux video le plus chère) ou a l'inverse MIN qui retourne la valeur minimum.Il y a aussi COUNT, qui permet de compter le nombre d'entrée dans une table par exemple */
	$requete->execute(array($_GET['console' ])); 
	$donnees = $requete->fetch() //Plu besoin d'une boucle pour afficher les résultats puisqu'il n'y a qu'une seul entré : prix_moyen//
	echo $donnees['prix_moyen'];

	$requete = $bdd->prepare('SELECT AVG(prix) AS prix_moyen, console FROM jeux_video GROUP BY console HAVING prix_moyen <= 10 ORDER BY prix_moyen') /*GROUP BY permet de grouper des données, on peut par exemple calculer le prix moyen des    																																jeux pour chaque console,on utilise GROUP BY en meme temps qu'une fonction d'agrégat, sinon c'est inutile.
																																	HAVING permet de filtrer les données une fois qu'elles ont était regrouper (par GROUP BY),HAVING
																																	ressemble a WHERE mais contrairement a WHERE il agit une fois que les donnée ont était regroupé
																																	a la fin des opération alors que WHERE le fait avant.*/




	$bdd = new PDO('mysql:host=localhost;dbname=test','root','', array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
	$requete = $bdd->prepare('INSERT INTO jeux_video(nom,possesseur,console,prix,nbre_joueurs_max,commentaires,date_ajout) VALUES('Northgard','Gerard','PC',20,1,'Jeu de stratégie','NOW())'')/*NOW est une fonction permettant
																																																d'ajouter la date et l'heure actuelle,
																																																on peut aussi directement écris la date/heure a la place.Il existe aussi CURTIME() et CURDATE qui retourne respectivement l'heure et la date*/

	$requete = $bdd->prepare('SELECT DAY(date_ajout) AS jour FROM jeux_video WHERE ID=52');//DAY() permet de récupérer le jour MONTH() le mois et YEAR()l'année et aussi HOUR() pour l'heure,MINUTE()pour les minutes,et SECOND()pour les seconde//
	
	$requete = $bdd->prepare('SELECT date_ajout, DATE_ADD(date_ajout, INTERVAL 15 DAY) AS date_plus_tard FROM jeux_video WHERE ID=52');/*DATE_ADD permet permet d'ajouter des jours,heures,mois,miunutes,secondes,semaines,etc... a date_ajout
																																		INTERVAL précise de combien.Il y a aussi DATE_SUB qui lui soustrais*/

	$requete = $bdd->prepare('SELECT pseudo, message, DATE_FORMAT(date_message, '%d/%m/%Y %Hh%imin%ss') AS date FROM minichat') /* DATE_FORMAT, permet de formater une date on peut ainsi adapter une date a notre format préférer,et ducoup
																																	tout récuperer dans un seul champ(date_message) et l'afficher grace a un echo par exemple.Ca evite de devoir
																																	préciser a chaque fois $donnees['jour'] '/' $donnees['mois'] '/' etc..*/
	