
<!DOCTYPE html>
<html lang="fr">
    <head>
        <meta charset="utf-8" />
        <link rel="stylesheet" href="" />
        <title>MiniChat</title>
    </head>
    
    <body>

    <style>
    	form
    	{
    		text-align: center;
    	}


    </style>
 	
 	
   	<form action="minichat_post.php" method="post">
   		<p>
   		<label for="pseudo">Pseudo :</label>
   		<input type="text" name="pseudo" id="pseudo" required value=<?php if(isset($_COOKIE['pseudo']))
   		{
   			echo htmlspecialchars($_COOKIE['pseudo']);
   		}?>><br/>
   		<label for ="message">Message :</label>
   		<input type="text" name="message" id="message" autofocus required><br/>
   		<input type="submit" value="Envoyer !"><br/>
   		<a href="minichat.php">Actualiser</a><br/>
   		<a href="minichat.php?page=1">Page 1</a>
   		<a href="minichat.php?page=2">Page 2</a>
   		<a href="minichat.php?page=3">Page 3</a>
   		<a href="minichat.php?page=4">Page 4</a>
   		</p>
   	</form>
	
	<?php	
	   	
		try
		{
			$bdd = new PDO('mysql:host=localhost;dbname=test;charset=utf8','root','', array(PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION));
		}
		   		
		catch(Exception $e)
		{
		 	die('Erreur : '.$e->getMessage());
		}

		if(isset($_GET['page']))
		{
			$_GET['page'] = (int) $_GET['page'];

			if($_GET['page'] <= 1 OR $_GET['page'] > 4)
			{
				$reponse = $bdd->query('SELECT pseudo,message,DATE_FORMAT(date_commentaire, \'[%d-%m-%Y %H:%i:%s]\') AS date_commentaire_fr FROM minichat ORDER BY date_commentaire DESC LIMIT 0,10');
			}

			elseif($_GET['page'] == 2)
			{
				$reponse = $bdd->query('SELECT pseudo,message,DATE_FORMAT(date_commentaire, \'[%d-%m-%Y %H:%i:%s]\' ) AS date_commentaire_fr FROM minichat ORDER BY date_commentaire DESC LIMIT 10,10');
			}

			elseif($_GET['page'] == 3)
			{
				$reponse = $bdd->query('SELECT pseudo,message,DATE_FORMAT(date_commentaire, \'[%d-%m-%Y %H:%i:%s]\') AS date_commentaire_fr FROM minichat ORDER BY date_commentaire DESC LIMIT 20,10');
			}

			elseif($_GET['page'] == 4)
			{
				$reponse = $bdd->query('SELECT pseudo,message,DATE_FORMAT(date_commentaire, \'[%d-%m-%Y %H:%i:%s]\') AS date_commentaire_fr FROM minichat ORDER BY date_commentaire DESC LIMIT 30,10');
			}
		}


		else
		{

		$reponse = $bdd->query('SELECT pseudo,message,DATE_FORMAT(date_commentaire, \'[%d-%m-%Y %H:%i:%s]\') AS date_commentaire_fr FROM minichat ORDER BY date_commentaire DESC LIMIT 0,10');
		}
		while($donnees = $reponse->fetch())
		{
		  echo '<p>' . htmlspecialchars($donnees['date_commentaire_fr']) . ' <strong>' . htmlspecialchars($donnees['pseudo']) . ' </strong>: ' . htmlspecialchars($donnees['message']) . '</p>';
		}
	  	

	?>
    </body>
</html>