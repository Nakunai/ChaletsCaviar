<!DOCTYPE html> 
<html> 
    <head lang="fr"> 
        <meta charset="utf-8" />
        <title>Copyright</title>
        <link rel="stylesheet" href="style.css"/>
    </head>   

    <body>

    <h1>Copyrightor</h1>
    

    <img src="copyrighter.php?image=couchersoleil.jpg" />
    
    </body>
</html>