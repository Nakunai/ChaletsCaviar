<!DOCTYPE html>
<html> 
    <head lang="fr"> 
        <meta charset="utf-8" />
        <title>Cartomania</title>
        <link rel="stylesheet" href="forumstyle2.css"/>
    </head>    

    
    <body>
        <?php
            try
            {
                $bdd = new PDO('mysql:host=localhost;dbname=cartomania;charset=utf8;', 'root','', array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
            }
            
            catch(Exception $e)
            {
                die('Erreur : ' . $e->getMessage());
            }

            if(isset($_COOKIE['pseudo'], $_COOKIE['pass']))
            {
                $req = $bdd->prepare('SELECT id FROM membres WHERE pseudo = ? AND pass = ?');
                $req->execute(array($_COOKIE['pseudo'], $_COOKIE['pass']));
                $resultat = $req->fetch();
                $req->closeCursor();

                if(!$resultat)
                {
                    echo 'ERREUR !';
                }

                else
                {
                    session_start();
                    $_SESSION['id'] = $resultat['id'];
                    $_SESSION['pseudo'] = $_COOKIE['pseudo'];
                    header('Location: espace_membre.php');
                }
            }


            if(isset($_POST['pseudo'], $_POST['pass']))
            {
                $pass_hache = sha1($_POST['pass']);
                $pseudo = htmlspecialchars($_POST['pseudo']);
                $pass_hache = htmlspecialchars($pass_hache);
                $req = $bdd->prepare('SELECT id FROM membres WHERE pseudo = ? AND pass = ?');
                $req->execute(array($pseudo, $pass_hache));
                $resultat = $req->fetch();
                $req->closeCursor();

                if(!$resultat)
                {
                    ?><span id="erreur_connexion">Pseudo ou mot de passe incorrect !</span><?php
                }

                 else
                {
                    if($_POST['auto_connexion'])
                    {
                        setcookie('pseudo', $pseudo, time() + 365*24*3600, null, null, false, true);
                        setcookie('pass', $pass_hache, time() + 365*24*3600, null, null, false, true);
                        session_start();
                        $_SESSION['id'] = $resultat['id'];
                        $_SESSION['pseudo'] = $pseudo;
                        header('Location: espace_membre.php');
                    }    
                    else
                    {
                        session_start();
                        $_SESSION['id'] = $resultat['id'];
                        $_SESSION['pseudo'] = $pseudo;
                        header('Location: espace_membre.php');
                    }
                }

            }
        ?>
            <header>
                <nav>
                    <a href="accueil.php" class="accueil_icone">Cartomania</a>
                    <div id="connexion_icone">
                        <a href="inscription.php">Créer un compte</a>
                        <a href="connexion.php">Se connecter</a>
                    </div>
                </nav>
            </header>
        
        <div id="bloc_formulaire">
            <h1>Connexion</h1>
            <div id="formulaire">
                <form method="post">
                        <label for="pseudo">Pseudo :</label> 
                        <input type="text" name="pseudo" id="pseudo"/><br/>
                        <label for="pass">Mot de passe :</label>
                        <input type="password" name="pass" id="pass"/><br/>
                        <label for="auto_connexion" id="label_connexion">Connexion automatique</label>
                        <input type="checkbox" name="auto_connexion" id="auto_connexion"/><br/>
                        <input type="submit" id="envoyer" value="Se connecter"/>
               	</form> 
            </div>
        </div>
    </body>
</html>