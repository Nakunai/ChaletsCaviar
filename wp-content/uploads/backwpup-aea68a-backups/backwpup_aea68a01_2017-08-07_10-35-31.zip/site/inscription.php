<!DOCTYPE html>
<html> 
    <head lang="fr"> 
        <meta charset="utf-8" />
        <title>Cartomania</title>
        <link rel="stylesheet" href="forumstyle2.css"/>
    </head>    

    
    <body>
        <?php
            
            try
            {
                $bdd = new PDO('mysql:host=localhost;dbname=cartomania;charset=utf8;', 'root','', array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
            }

            catch(Exception $e)
            {
                die('Erreur : ' . $e->getMessage());
            }
        
        if(isset($_POST['pseudo']))
        {
            $requete = $bdd->prepare('SELECT pseudo FROM membres WHERE pseudo = ?');
            $requete->execute(array($_POST['pseudo']));
            $donnees = $requete->fetch();
            $requete->closeCursor();

            if(empty($donnees['pseudo']))
            {
                if(preg_match('#^[a-zA-Z0-9_-]{1,9}$#', $_POST['pseudo']))
                {
                   if(isset($_POST['pass'], $_POST['pass_confirme']) && $_POST['pass'] == $_POST['pass_confirme'])
                   {
                        if(preg_match('#^[a-zA-Z0-9_-]{6,}$#', $_POST['pass']))
                        {
                            $pass_hache = sha1($_POST['pass']);
                            if(isset($_POST['email']))
                            {
                                if(preg_match('#^[a-z0-9._-]+@[a-z0-9._-]{2,}\.[a-z]{2,4}$#', $_POST['email']))
                                {
                                     $pseudo = htmlspecialchars($_POST['pseudo']);
                                    $pass_hache = htmlspecialchars($pass_hache);
                                    $email = htmlspecialchars($_POST['email']);
                                    $req = $bdd->prepare('INSERT INTO membres(pseudo,pass,email,date_inscription)VALUES(:pseudo,:pass,:email,CURDATE())');
                                    $req->execute(array('pseudo' => $pseudo,'pass' => $pass_hache, 'email' => $email));
                                    $req->closeCursor();
                                    header('Location: connexion.php');

                                }
                                else
                                {
                                    ?><span id="erreur_mail">Email invalide !</span><?php
                                }
                            }
                            
                        }
                        else
                        {
                            ?><span id="erreur_pass1">Mot de passe invalide !</span><?php
                        }
                   }

                   elseif($_POST['pass'] !== $_POST['pass_confirme'])
                   {
                        ?><span id="erreur_pass">Les deux mots de passe sont différent, réessayer !</span><?php
                   }


                }
                
                else
                {
                    ?><span id="pseudo_exist">Pseudo invalide !</span><?php
                }
            }

            else
            {
                ?><span id="erreur_pseudo">Ce pseudo existe deja !</span><?php
            }
        }
        ?>
        <header>
            <nav>
                <a href="accueil.php" class="accueil_icone">Cartomania</a>
                <div id="connexion_icone">
                    <a href="inscription.php">Créer un compte</a>
                    <a href="connexion.php">Se connecter</a>
                </div>
            </nav>
        </header>
        
        <div id="bloc_inscription">
            <h1>Inscription</h1>
            <div id="formulaire_inscription">
                <form method="post">
                        <label for="pseudo">Pseudo :</label> 
                        <input type="text" name="pseudo" id="name"/><br/>
                        <label for="pass">Mot de passe :</label>
                        <input type="password" name="pass" id="pass"/><br/>
                        <label for="pass_confirme">Retapez votre mot de passe :</label>
                        <input type="password" name="pass_confirme" id="pass_confirme"/><br/>
                        <label for="email">Adresse email :</label>
                        <input name="email" id="email"/><br/>
                        <input type="submit" id="inscription" value="S'inscrire !"/>
                </form>
                <a href="connexion.php" class="lien_connexion">Se connecter</a>
            </div>
        </div>
    </body>
</html>