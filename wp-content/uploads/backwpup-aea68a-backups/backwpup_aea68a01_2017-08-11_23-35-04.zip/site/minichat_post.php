<?php
setcookie('pseudo',$_POST['pseudo'],time() + 365*24*3600, null, null, false, true);

$longueur_pseudo = strlen($_POST['pseudo']);
$longueur_message = strlen($_POST['message']);

try
{
	$bdd = new PDO('mysql:host=localhost;dbname=test;charset=utf8','root','', array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));

}

catch(Exception $e)
{
	die('Erreur : '.$e->getMessage());
}


if($longueur_pseudo <= 20 && $longueur_message <=255)
{
	if(isset($_POST['pseudo'], $_POST['message']) && $_POST['pseudo'] !== '' && $_POST['message'] !== '')
	{
		
			$requete = $bdd->prepare('INSERT INTO minichat(pseudo, message,date_commentaire) VALUES(?, ?,NOW())');
			$requete->execute(array($_POST['pseudo'], $_POST['message']));
			header('Location: minichat.php');
	}
	header('Location: minichat.php');
}
header('Location: minichat.php');


$requete->closeCursor();
?>


