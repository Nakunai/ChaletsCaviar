<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>Ma page web</title>
    </head>
    <body>
        <h1>Ma page web</h1>
        <p>Aujourd'hui nous sommes le </p>
        <?php echo "Bonjour !";?> <!--Code php,une balise php peut etre placer n'importe ou(meme entre code html,elle peut prendre plusieurs ligne.l'instruction echo sert a afficher du texte-->
        <?php echo "Cette ligne a été écrite \"uniquement\" en PHP."; ?> <!--On peut afficher les "" avec \ -->
        <?php
echo "J'habite en Chine.<br/>"; // Commentaire php //(les commentaire ce trouve a l'interieur d'une balise php) pour un commentaire multiligne /* */ //


echo "J'ai 92 ans.";
?>	

<?php

$ageduvisiteur = 20; // $ Permet d'initialiser une variable, une variable peut contenir un nombre,du texte("Bonjour" ou 'Bonjour') et des nombre a virgule(1.2) //
echo $ageduvisiteur;                    
$estcevrai = true; //Une variable peut aussi contenir une valeur true ou false (vrai/faux) ou une valeurs NUll (rien) //
echo 'Le visiteur a '.$ageduvisiteur.' ans'; //Afin de mieux differencier le texte par rapport au variable,on entoure le text de '' et les variable de '..'//
$prix = 2.5;
$quantite = 10;
$total = $prix * $quantite;
'Cela couterait '.$total.' euros.'; 
if ($ageduvisiteur < 12) // Ceci est une condition if (ex: si age du visiteur inferieur a 12 alors affiche ce message). == >= <= < > =!(different//
{
    echo 'Salut gamin !';
}

elseif ($ageduvisiteur = 14) // sinon si (ex:sinon si le visiteur a 14 ans affiche ca) //
{
    echo 'Tu as 14 ans <br/>';
}

else //Condition else (sinon) //
{
    echo'Bonjour Monsieur <br/>';
}

$adulte = true;
$nom ="Bernard";

if($adulte) //== n'est pas obligatoire on peut abreger de cette façon.On peut aussi mettre un ! pour dire différent (ex: si tu n'est pas un adulte) if(!adulte) //
{
    echo'Tu es un adulte';
}

else
{
    echo 'Tu es un enfant';
}

if($adulte AND $nom =="Bernard" ) /*On peut aussi mettre AND(ou &&) pour dire par ex: si adulte est vrai et nom =bernard.Et aussi OR(ou ||) ex: si adulte ou 
                                    nom=Bernard */
?>

<?php

$adulte= true;
$age = 20;

if ($adulte)
{
?>                      
<p>Tu es un adulte ! <br/> </p>    

<?php //On peut aussi couper la balise php afin d'integrer du text en html par exemple //
}

$age = 20;
switch ($age) //Condition permettant de tester plusieur fois la variable.Plus simple que d'écrire elseif a chaque fois dans ce type de cas //
{ 
    case 4: //Attention : et non ; //
        echo'Tu as 4 ans';
        break;
    case 8:
        echo'Tu as 8 ans';
        break;
    case 18:
        echo 'Tu es majeur';
        break;
    default://Equivalent de else(sinon)//  
        echo "Désolé, je n'ai pas de message à afficher pour cette note";  
}
$age = 24;

$majeur = ($age >= 18) ? true : false; //Ceci est une condition teraire qui execute 2 condition sur une seule ligne//

?>

<?php

  $repetition = 0;

while($repetition < 10) //Boucle while qui permet de répeter une action, par ex : tant que la variable repetition n'est pas a 10 affiche ce message//
{
    echo '<p>Je ne dois pas copier sur mon voisin '.$repetition.' fois</p>';
    $repetition++; //Permet de monter la variable de +1, plus simple que d'écrire $repetition = $repetition + 1; //
}    



for($repetition1 = 0; $repetition1 <10; $repetition1++) /*Semblable a la bouble while mais on peut tout faire dans la boucle,initialisation de la
                                                        variable,test de la variable(condition),instruction qu'on execute a chaque tour de boucle
                                                        (incrémentation)*/
{
    echo'<p>Tu as perdu '.$repetition1.' vie <br/>';
}

$prenom[0] = 'Corinne'; /*Ceci est un tableau numéroté (un array) on peut donner plusieurs valeurs a une variable (ici prenom).Un tableau numéroté commence 
                            toujours par 0, ces numéros sont appelé clé.On peut aussi laisser php sélectionner les numéro en laissant les [] vide 
                            Les arrays numérotés permettent de stocker une série d'éléments du même type, comme des prénoms. Chaque élément du tableau contiendra alors un prénom. */   
$prenom[1] = 'Enzo';        
$prenom[2] = 'Marie';

$prenom1 = array('Robert', 'Roby', 'Jose'); //On utilise généralement la fonction array pour créer un tableau numéroté en gardant toujours l'ordre 0,1,2,3...//

echo $prenom[1]; //On peut afficher ce que contient la case 1 du tableau par exemple//

print_r($prenom1); //La fonction print_r permet de répresenter et d'afficher le contenu d'un tableau.Ca sert surtout à debugger,pour comprendre les erreurs//

$personne = array('nom' => 'Cavailles', 'prenom2' => 'Thibault', 'age' => 21);/*Ceci est un tableau associatif,au lieu de numéroté les cases on va leurs donner
                                                                                un nom,un libellé.On écrit => pour associé
                                                                                 Les arrays associatifs permettent de découper une donnée en plusieurs sous-éléments. Par exemple, une adresse peut être découpée en nom, prénom, nom de rue, ville…*/       

$coordonnees['prenom'] = 'François';//Il est aussi possible de créer un tableau case par case de cette façon//
$coordonnees['nom'] = 'Dupont';
$coordonnees['adresse'] = '3 Rue du Paradis';
$coordonnees['ville'] = 'Marseille';

echo $coordonnees['ville'];

$prenoms = array ('François', 'Michel', 'Nicole', 'Véronique', 'Benoît');

for ($numero = 0; $numero < 5; $numero++) //On peut afficher toute les cases d'un tableau à l'aide d'une boucle for//
{
    echo '<p>'.$prenoms[$numero].'</p>';

}

$prenom2 = array ('Jacque', 'Christine', 'Alex', 'Clemence', 'Paul');

foreach ($prenom2 as $prenom3) /*foreach est un type de boucle spécialement faite pour les tableaux.foreach va passer en revue chaque ligne du tableau, et lors de 
                                chaque passage, elle va mettre la valeur de cette ligne dans une variable temporaire (par exemple $prenom3).
                                 On peut aussi le faire pour un tableau associatif*/

{
    echo '<p>'.$prenom3.'</p>';
}

foreach($personne as $libelle => $detail) //On peut même afficher le libellé de chaque cases de cette façon//
{
    echo'<p>' .$libelle. ' vaut ' .$detail. '</p>';
}

echo '<pre>'; /*On peut utiliser print_r pour afficher un tableau mais celle-ci ne renvoi pas le code html.On peut donc ce servir de la balise html<pre>
                pour afficher de façon un peu plus correct le tableau.Cela sert surtout pour debugué.*/

print_r($coordonnees);
echo '</pre>';

if (array_key_exists('nom', $coordonnees)) //On peut vérifier si une clé existe dans un tableau de cette maniere//
{
    echo 'La clé "nom" se trouve dans les coordonnées !';
}

if (array_key_exists('pays', $coordonnees))
{
    echo 'La clé "pays" se trouve dans les coordonnées !';
}

$fruits = array ('Banane', 'Pomme', 'Poire', 'Cerise', 'Fraise', 'Framboise');

if (in_array('Myrtille', $fruits)) //in_array pareil que clé sauf que ici c'est pour la valeur, la fonction renvoi un booléen (true false)//
{
    echo 'La valeur "Myrtille" se trouve dans les fruits !';
}

if (in_array('Cerise', $fruits))
{
    echo 'La valeur "Cerise" se trouve dans les fruits !';
}

$position = array_search('Fraise', $fruits); //array_search, semblable a in_array mais cette fois ci elle récupère la clé d'une valeurs //
echo '"Fraise" se trouve en position ' . $position . '<br />';

$position = array_search('Banane', $fruits);
echo '"Banane" se trouve en position '. $position .' <br/>';

$phrase = 'Bonjour je suis une phrase.';
$nombreDeCaracteres = strlen($phrase); /*strlen est une fonction, elle permet de de compter le nombre de caractère dans la variable phrase et retourne le
                                        résultat à la variable nombreDeCaracteres*/

echo 'Il y à '.$nombreDeCaracteres.' caracteres dans cette phrase <br/>';

$phrase1 ='Bonjour je suis un chat <br/>';
echo str_shuffle($phrase1); /*str_shuffle est une fonction, elle permet de mélanger au hasard les caractères.Ici on peut directement afficher le
                                le resultat de la fonction str_shuffle dans un echo sans forcémenent le stocker dans une variable*/                  

echo str_shuffle('Ma phrase'); //On pourrais aussi faire de cette manière sans variable//

$jour = date('d');/*date est une fonction, elle fais des calcul est nous retourne le numéro du mois,du jour,année,heure,minute,... 
                    heure('H'),minute('i'),jour('d'),mois('m'),année('Y') Bien respecter majuscule/minuscule*/
$mois = date('m');
$annee = date('Y');
$heure = date('H');
$minute = date('i');

echo'Bonjour nous sommes le ' .$jour. '/' .$mois. '/' .$annee. ' et il est'.$heure.'h'.$minute.'.';

function direBonjour($heros) /*Permet de déclarer une fonction, rien ne se passe tant que l'on ne l'apelle pas.on peut mettre plusieurs paramètre dans une fonction
                                en les séparant par une virgule.Certaines fonction ne renvoi pas de valeurs mais font quand memes des actions*/
{
    echo'<p>Bonjour '. $heros .'<p>';
}

direBonjour('Marie'); //Appel de la fonction, dans cette ex: la valeurs Marie seras mis dans la variable $nom//
direBonjour('Pierre'); //On peut appeller plusieurs fois une fonction et ainsi éviter un travail répetitif// 
direBonjour('Darvador');
direBonjour('Darkpador');
direBonjour('Fuckpador');

$ma_variable = str_replace('b', 'p', 'bim bam boum');/* str_replace remplace une chaîne de caractères par une autre.On a besoin d'indiquer 3 paramètres :
                                                        la châines que l'on recherche (ici b), la chaîne qu'on veut mettre à la place (ici, on met des p a
                                                        la place des b),la chaîne dans laquelle on doit faire la recherche.*/
echo $ma_variable;
?>

<p>
    <a href="bonjour.php?nom=Cavailles&amp;prenom=Thibault">Dis moi bonjour</a> <!--Pour ecrire & dans une adresse il faut rajouter amp; le ? sépare le nom 
                                                                                de la page des parametre (ce qu'il ya après).nom/prenom sont de parametre
                                                                                et Cavailles/Thibault des valeurs-->
</p>

<form action ="cible.php" method="POST">
    <p><label>Prénom : <input type="text" name="prenom"/></label></p>
    <p><label>Ëtes vous végétarien ? <input type="checkbox" name="vegetarien"/></label></p>
    <p><input type="submit" name="Envoyer"/></p>
</form>
<?php
    $monfichier = fopen('compteur.txt', 'r+'); /*fopen permet d'ouvrir un fichier pour y stocker des infos par exemple, r ouvre fichier en lecture seule,
                                                r+ lecture+écriture,a ouvre fichier en lecture seule mais si il n'existe pas il est créer,a+ lecture-écriture
                                                et créer un fichier si il n'existe pas*/
    $pages_vues = fgets($monfichier);/*fgets permet de lire ligne par ligne dans le fichier, fgetc lis caractère par                                       
                                            caractère*/
    $pages_vues += 1;
    fseek($monfichier, 0); /*fseek permet de replacer le curseur,ici 0 donc au début de la ligne,ce qui va permettre d'écrire par dessus ce qui a deja était
                            écris*/
    fputs($monfichier, $pages_vues); //fonction fputs permet d'écrire dans le fichier//

    
    fclose($monfichier); //fclose ferme le fichier//
    echo '<p>Cette page a été vue ' . $pages_vues . ' fois !</p>';


    

    ?>
    </body>
</html>