<!DOCTYPE html>
<html>
    <head lang="fr">
        <meta charset="utf-8" />
        <title>Formulaire</title>
    </head>


	<body>

		
		<?php
		if(isset($_POST['motdepasse']) == NULL)
		{
			?>
			<form method="POST" action="formulaire.php">
    		<p><label>Mot de passe<input type="password" name="motdepasse" required/></label></p>
			<p><input type="submit" name="Envoyer !"/></p>
			<?php
		}
    	
    	elseif($_POST['motdepasse'] != 'kangourou')
    	{
    		echo 'Mot de passe incorrect';
    	}

    	else
    	{
    		echo 'Voila le code 21525251515';
    	}


    	
    	?>


	</body>


</html>    