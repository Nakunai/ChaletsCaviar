<footer>
        <div id="tweet">
            <h1>Mon dernier tweet</h1>
            <p>Hii haaaaaan !</p>
            <p>le 12 mai à 23h12</p>
        </div>
        
        <div id="mes_photos">
            <h1>Mes photos</h1>
            <p><img src="images/photo1.jpg" alt="Photographie" /><img src="images/photo2.jpg" alt="Photographie" /><img src="images/photo3.jpg" alt="Photographie" /><img src="images/photo4.jpg" alt="Photographie" /></p>
        </div>
        
        <div id="mes_amis">
            <h1>Mes amis</h1>
            <div id="listes_amis">
                <ul>
                    <li><a href="#">Pupi le lapin</a></li>
                    <li><a href="#">Mr Baobab</a></li>
                    <li><a href="#">Kaiwaii</a></li>
                    <li><a href="#">Perceval.eu</a></li>
                </ul>
                <ul>
                    <li><a href="#">Belette</a></li>
                    <li><a href="#">Le concombre masqué</a></li>
                    <li><a href="#">Ptit prince</a></li>
                    <li><a href="#">Mr Fan</a></li>
                </ul>
            </div>
        </div>
</footer>